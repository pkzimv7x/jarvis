package com.jarvis.app

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val idle = "J.A.R.V.I.S."
    private val violet = Color.parseColor("#B388FF")
    private lateinit var status: TextView
    private lateinit var reply: TextView
    private lateinit var core: View
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val history = JSONArray()

    private val pulse = ValueAnimator.ofFloat(0.9f, 1.1f).apply {
        duration = 700
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener {
            val v = it.animatedValue as Float
            core.scaleX = v
            core.scaleY = v
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#12002B")
        window.navigationBarColor = Color.parseColor("#3B0F8C")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#12002B"), Color.parseColor("#3B0F8C"))
            )
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        status = TextView(this).apply {
            text = idle; setTextColor(violet); textSize = 22f
            typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER
        }
        core = FrameLayout(this).apply {
            addView(View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#22B388FF"))
                    setStroke(dp(4), violet)
                }
            }, FrameLayout.LayoutParams(-1, -1))
            addView(View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#88B388FF"))
                }
            }, FrameLayout.LayoutParams(dp(80), dp(80), Gravity.CENTER))
        }
        reply = TextView(this).apply {
            setTextColor(Color.parseColor("#EDE7FF")); textSize = 16f
            typeface = Typeface.MONOSPACE
        }
        val talk = Button(this).apply {
            text = "FALAR"; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#7C4DFF"))
            }
            setOnClickListener { listen() }
        }
        val keyLink = TextView(this).apply {
            text = "configurar chave"; setTextColor(Color.parseColor("#B39DDB"))
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0)
            setOnClickListener { askKey() }
        }

        root.addView(status)
        root.addView(core, LinearLayout.LayoutParams(dp(180), dp(180)).apply {
            topMargin = dp(32); bottomMargin = dp(32)
        })
        root.addView(ScrollView(this).apply { addView(reply) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(talk, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(keyLink, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        tts = TextToSpeech(this, this)
        if (prefs().getString("key", "").isNullOrEmpty()) askKey()
    }

    override fun onInit(s: Int) {
        tts?.language = Locale("pt", "BR")
        tts?.setPitch(0.8f)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { runOnUiThread { setState(idle, false) } }
            override fun onError(id: String?) { runOnUiThread { setState(idle, false) } }
        })
    }

    private fun setState(t: String, active: Boolean) {
        status.text = t
        if (active) {
            if (!pulse.isRunning) pulse.start()
        } else {
            pulse.cancel(); core.scaleX = 1f; core.scaleY = 1f
        }
    }

    private fun askKey() {
        val et = EditText(this).apply {
            hint = "sk-ant-..."; setText(prefs().getString("key", ""))
        }
        AlertDialog.Builder(this).setTitle("Chave da API Anthropic").setView(et)
            .setPositiveButton("Salvar") { _, _ ->
                prefs().edit().putString("key", et.text.toString().trim()).apply()
            }.show()
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply.text = "Reconhecimento de voz indisponível neste aparelho."; return
        }
        tts?.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) setState(idle, false) else ask(t)
                }
                override fun onError(e: Int) { setState("Não ouvi, chefe.", false) }
                override fun onReadyForSpeech(p: Bundle?) { setState("OUVINDO...", true) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            })
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) listen()
    }

    private fun ask(text: String) {
        setState("PROCESSANDO...", true)
        reply.text = "> $text"
        val key = prefs().getString("key", "") ?: ""
        if (history.length() >= 10) { history.remove(0); history.remove(0) }
        Thread {
            val answer = try {
                history.put(JSONObject().put("role", "user").put("content", text))
                val body = JSONObject()
                    .put("model", "claude-haiku-5-5")
                    .put("max_tokens", 300)
                    .put("system", "Você é J.A.R.V.I.S., assistente pessoal sofisticado, de humor sutil. Responda em português do Brasil, em no máximo 3 frases curtas, sem markdown, pois sua resposta será falada em voz alta. Chame o usuário de chefe ocasionalmente.")
                    .put("messages", history)
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val ok = c.responseCode in 200..299
                val raw = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                if (!ok) throw Exception(if (c.responseCode == 401) "chave inválida" else "erro ${c.responseCode}")
                val t = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
                history.put(JSONObject().put("role", "assistant").put("content", t))
                t
            } catch (e: Exception) {
                if (history.length() % 2 == 1) history.remove(history.length() - 1)
                "Falha na conexão com a API, chefe: ${e.message}"
            }
            runOnUiThread {
                reply.text = "> $text\n\n$answer"
                setState("FALANDO...", true)
                tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "j")
            }
        }.start()
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }
}
